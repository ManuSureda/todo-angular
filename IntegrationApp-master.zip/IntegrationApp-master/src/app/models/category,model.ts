export class ProductCategory{
    productCategoryId: number;
    description: string;
}