export class Product{
    productId: number;
    productCategoryId: number;
    productCategoryName: string;
    name: string;
    description: string;
    price: number;
}