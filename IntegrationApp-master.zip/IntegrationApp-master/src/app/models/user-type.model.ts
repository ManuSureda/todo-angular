export class UserType{
    userTypeId: number;
    type: string;
}