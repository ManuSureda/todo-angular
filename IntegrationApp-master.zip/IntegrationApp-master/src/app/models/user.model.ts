export class User{
    userId: number;
    userType: number;
    name: string;
    email: string;
    password: string;
}