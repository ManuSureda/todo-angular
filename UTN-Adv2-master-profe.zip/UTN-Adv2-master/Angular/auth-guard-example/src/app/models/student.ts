export class Student {
    studentId: number;
    firstName: string;
    lastName: string;
    email: string;
    dni: string;
    address: string;
    careerId: number;
}
