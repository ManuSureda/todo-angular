//car.ts
export class Car {
    public brand;
    public model;    
}

