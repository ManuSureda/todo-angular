//models/car.ts
export class Car {
    brand : string;
    model : string;
}