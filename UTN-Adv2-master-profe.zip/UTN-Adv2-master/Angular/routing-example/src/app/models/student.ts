export class Student {
    studentId: number;
    lastName: string;
    firstName: string;
    dni: string;
    email: string;
    address: string;
}
