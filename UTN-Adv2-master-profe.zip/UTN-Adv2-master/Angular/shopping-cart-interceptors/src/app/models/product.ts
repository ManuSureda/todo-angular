export class Product {
    productId: number;
    productCategoryId: number;
    name: string;
    description: string;
    price: number;
}
