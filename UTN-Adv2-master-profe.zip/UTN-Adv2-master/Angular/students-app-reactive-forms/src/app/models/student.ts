export class Student {
    studentId: number;
    firstName: string;
    lastName: string;   
    dni: number;
    email: string;
    address: string;
}
