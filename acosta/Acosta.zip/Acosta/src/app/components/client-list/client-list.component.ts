import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import Client from 'src/app/model/Client';
import { ClientService } from 'src/app/service/client.service';

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})
export class ClientListComponent implements OnInit {

  public clients: Client[];
  public clientDeleteFormGroup: FormGroup;
  public deleteError: boolean;

  constructor(private clientService: ClientService) { }

  ngOnInit(): void {
    this.clientDeleteFormGroup = new FormGroup({
      'clientId': new FormControl('', Validators.required)
    });

    this.clientService.getAll().subscribe(data => {
      this.clients = data as Client[];
    },
    error => {
      console.error(error);
    });
  }

  onDeleteClient(id: number) {
    this.deleteError = false;

    this.clientService.delete(id).subscribe(res => {
      console.log(res);
    }, 
    error => {
      this.deleteError = true;
    });
  }

}
