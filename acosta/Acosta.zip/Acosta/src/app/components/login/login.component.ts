import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public loginFormGroup: FormGroup;

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.loginFormGroup = new FormGroup({
      'email': new FormControl('', [ Validators.required, Validators.email ]),
      'password': new FormControl('', Validators.required)
    });
  }

  onSubmit() {
    this.authService.login(this.loginFormGroup.value['email'], this.loginFormGroup.value['password']).subscribe(res => {
      sessionStorage.setItem('token', res['token']);
    });
  }

}
