export default class Client {
    clientId: number;
    firstName: string;
    lastName: string;
    email: string;
    creditCardType: string;
    creditCardNumber: number;
    debt: number;
}