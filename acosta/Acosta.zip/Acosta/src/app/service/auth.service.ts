import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpClient: HttpClient) { }

  login(email: string, password: string) {
    return this.httpClient.post('https://utn-lubnan-api-1.herokuapp.com/api/User/Login', {
      email,
      password
    });
  }

  getAuthorizationToken() {
    return sessionStorage.getItem('token');
  }

}
