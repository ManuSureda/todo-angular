import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  delete(id: number) {
    return this.httpClient.get(`https://utn-lubnan-api-1.herokuapp.com/api/Client/${id}`);
  }

  constructor(private httpClient: HttpClient) { }

  getAll() {
    return this.httpClient.get('https://utn-lubnan-api-1.herokuapp.com/api/Client');
  }

}
