import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Incident } from 'src/app/models/incident';
import { Priority } from 'src/app/models/priority';
import { IncidentService } from 'src/app/services/incident.service';
import { PriorityService } from 'src/app/services/priority.service';
import { CustomValidators } from 'src/app/validators/custom-validators';

@Component({
  selector: 'app-incident-add',
  templateUrl: './incident-add.component.html',
  styleUrls: ['./incident-add.component.css']
})
export class IncidentAddComponent implements OnInit {

  priorityList: Array<Priority>;
  message: string;

  incidentForm = new FormGroup({
    domain: new FormControl("" , [ Validators.required ]),
    title: new FormControl("" , [ Validators.required ]),
    description: new FormControl("" , [ Validators.required ]),
    creator: new FormControl("" , [ Validators.required ]),
    phoneNumber: new FormControl("" , [ Validators.required, CustomValidators.numbersOnly()])
  })

  constructor(private incidentService: IncidentService , private priorityService: PriorityService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.priorityService.getAll()
      .then(response => {
        this.priorityList = response;


      })
      .catch(error => {
        console.log(error);
      })
  }

  onSubmit(){
    let incident = new Incident();
    let idAux = this.incidentService.getAll();

    //aca tendria que reccorrer los incidents y ver cual fue la ultima id
    //y sumarle uno pero lo hago asi por cuestion de tiempo
    incident.incidentId = 1;

    incident.priorityId = this.incidentForm.get('priorityId').value;

    incident.title = this.incidentForm.get('title').value;    
    incident.creator = this.incidentForm.get('creator').value;
    incident.description = this.incidentForm.get('description').value;
    incident.domainName = this.incidentForm.get('domain').value;
    if(this.incidentForm.get('phoneNumber') != null){
      incident.phoneNumber = this.incidentForm.get('phoneNumber').value;
    } else {
      incident.phoneNumber = "";
    }

    this.incidentService.add(incident)
      .then(response => {
        this.message = "se agrego";
      })
      .catch(error => {
        this.message = error;
      })

  }
}
