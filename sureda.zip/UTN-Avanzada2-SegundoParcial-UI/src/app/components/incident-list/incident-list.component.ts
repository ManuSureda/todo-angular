import { Component, OnInit } from '@angular/core';
import { Incident } from 'src/app/models/incident';
import { IncidentService } from 'src/app/services/incident.service';

@Component({
  selector: 'app-incident-list',
  templateUrl: './incident-list.component.html',
  styleUrls: ['./incident-list.component.css']
})
export class IncidentListComponent implements OnInit {

  incidentList = Array<Incident>();

  constructor(private incidentService: IncidentService) { }

  ngOnInit(): void {
    this.incidentService.getAll()
      .then(response => {
        this.incidentList = response;
      })
      .catch(error => {
        console.log(error);
      })
  }

}
