export class Domain {
    domainId: number;
    name: string;
    ipAddress: string;
    isActive: boolean;
}
