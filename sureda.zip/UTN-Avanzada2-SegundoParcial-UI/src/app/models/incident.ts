export class Incident {
  incidentId: number;
  priorityId: number;
  title: string;
  creator: string;
  description: string;
  domainName: string;
  phoneNumber: string;
}
