export class Priority {
    priorityId: number;
    description: string;
}
