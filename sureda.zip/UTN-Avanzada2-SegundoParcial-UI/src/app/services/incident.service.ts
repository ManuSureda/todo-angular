import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Incident } from '../models/incident';

@Injectable({
  providedIn: 'root'
})
export class IncidentService {

  private apiURL = 'https://utn-lubnan-api-1.herokuapp.com/api/Incident';

  private httpOptions = {
    headers: new HttpHeaders({
      'content-type':'application/json'
    })
  };

  constructor( private http: HttpClient) { 

  }

  getAll(): Promise<any>{
    return this.http.get(this.apiURL).toPromise();
  }

  add(incident: Incident): Promise<any>{
    return this.http.post(this.apiURL,incident,this.httpOptions).toPromise();
  }

}